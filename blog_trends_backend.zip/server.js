
const express = require("express");
const cors = require("cors");
const fs = require("fs-extra");
const googleTrends = require("google-trends-api");
const cron = require("node-cron");
const path = require("path");

const app = express();
app.use(cors());
app.use(express.json());

const DATA_FILE = path.join(__dirname, "data", "trends.json");

async function updateTrends() {
  try {
    const results = await googleTrends.dailyTrends({
      geo: "BR",
    });
    const data = JSON.parse(results);

    const trends = data.default.trendingSearchesDays.flatMap(day =>
      day.trendingSearches.map(search => ({
        title: search.title.query,
        excerpt: search.snippets?.[0] || "Veja mais detalhes no Google Trends.",
        url: search.shareUrl
      }))
    );

    await fs.writeJson(DATA_FILE, trends.slice(0, 20), { spaces: 2 });
    console.log("✅ Trends atualizadas com sucesso!");
  } catch (error) {
    console.error("❌ Erro ao atualizar Trends:", error);
  }
}

// Atualização ao iniciar
updateTrends();

// Cron job a cada 12 horas
cron.schedule("0 */12 * * *", () => {
  console.log("🔄 Atualizando Trends via CRON...");
  updateTrends();
});

// Endpoint público
app.get("/api/google-trends-news", async (req, res) => {
  try {
    if (!fs.existsSync(DATA_FILE)) {
      return res.json([]);
    }
    const fileData = await fs.readJson(DATA_FILE);
    res.json(fileData);
  } catch (error) {
    res.status(500).json({ error: "Erro ao obter dados" });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log("🚀 Servidor rodando na porta", PORT));
